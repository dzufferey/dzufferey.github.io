#!/bin/sh

rm *.dot *.svg *.html
