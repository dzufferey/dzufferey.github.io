package picasso

object Main {

  def main(args: Array[String]): Unit = {
    Console.println("Hello World")
  }
}
