object HelloWorld {

  def print = {
    println("Hello, world!")
  }
  def main(args: Array[String]) {
    print
  }
}
