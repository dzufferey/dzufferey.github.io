object Main {
  def main(args: Array[String]) {
    assert(true)
  }
}
