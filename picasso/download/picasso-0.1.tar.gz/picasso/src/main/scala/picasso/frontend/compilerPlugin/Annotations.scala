package picasso.frontend.compilerPlugin

object Annotations {

  class Predicate extends StaticAnnotation

}
